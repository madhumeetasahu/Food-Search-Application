# ltw-t03-g03

![img](https://github.com/golangis/LTW-2021-2022/blob/main/Projeto/images/logo.png)
## Features

- [x] Register
- [x] Login/Logout
- [x] Edit Profile
- [x] Add Restaurant
- [x] Edit Restaurant
- [x] Add Dishes
- [x] Add Dish Photo
- [x] List Reviews
- [x] Restaurant Owner Can Answer to Review
- [x] List Customer Orders
- [x] Change Order State
- [x] Search Restaurants
- [x] Order Dishes
- [x] List My Orders
- [x] Mark Restaurant as Favourite
- [x] Mark Dish as Favourite
- [x] Customer Can Leave a Review

## Credentials
- margarida ``pass123``
- mariana ``pass123``
- matilde ``pass123``

## Team
- Margarida Cosme
- Mariana Solange
- Matilde Silva
